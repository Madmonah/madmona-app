# Madmona — Session Changes Summary
**Date:** 2026-05-12  
**Goal:** Auto-approve all registrations, fix duplicate-drafts bug, rename TopNav button, stop the "wrong photos" auto-publish, prep clean state for the MUA campaign.

---

## ✅ Changes Applied Directly to Supabase (LIVE NOW)

### 1. Auto-approve all supplier registrations
- `marketplace_suppliers.kyc_status` default → `'approved'`
- `suppliers.status` default → `'approved'`
- BEFORE INSERT triggers force-approve any incoming row (even if app sends `'pending'`)
- Backfilled all existing `pending`/`suspended` → `approved`
- **Result:** 19 marketplace_suppliers + 3 suppliers all `approved`. No manual approval queue anymore.

### 2. Smart auto-publish for listings (no admin review needed)
- `claim_listing_draft()` function updated:
  - If draft has **category + real title + city + price + ≥1 photo** → listing goes live `published`
  - If draft is partial → `pending_review` (won't show on site)
  - **No more empty placeholders leaking to the marketplace.**

### 3. Stopped wrong auto-images on social posts
- `queue_social_pack_on_publish()` trigger now requires the listing to have at least 1 real photo in `listing_photos`. No photos = no social post.
- Skips listings with placeholder titles (`في انتظار التفاصيل`, `جاري التحرير`)
- **Cleanup:** deleted 12 bogus `content_calendar` entries + 4 orphan `social_packs` that had random Unsplash images attached to empty listings.

### 4. Paused 4 placeholder listings
- IDs: `d31ddd3e` (شيرين), `d9865c77` (معتز), `19d685b7` (Hosam), `9d240955` (خالد)
- They were `published` with title `"ليستنج جديد - X - في انتظار التفاصيل"` and no content. Now `paused`. They won't reappear unless the supplier completes the wizard.

---

## ⚠️ Frontend Changes — REQUIRES deploy.bat

Three files modified. Copy them over `C:\madmona-app\...` and run `deploy.bat`.

### File 1: `src/app/api/listing-drafts/route.ts`
**What changed:** POST endpoint deduplicates by phone.

**Logic:** Before creating a new draft, look up any open draft (`status IN ('draft','submitted')`) from the same phone in the last 7 days. If found, return that token instead of creating a duplicate row.

**Why:** This is the root cause of "مكاريوس عمل 6 drafts لنفس العربية". Every WhatsApp link re-tap was creating a new row. Now they continue the existing draft.

### File 2: `src/app/add-listing/AddListingClient.tsx`
**What changed:**
1. On page load, restore token from `localStorage` if URL doesn't have one
2. Hydrate full draft state from DB (so users see what they typed before)
3. Resume at the same step they left off
4. Clear `localStorage` after successful submission (so next visit is a fresh listing)

**Why:** Combined with the POST dedup, this stops the duplicate-draft explosion entirely. Users can close the WhatsApp browser, re-open the link, and continue exactly where they were.

### File 3: `src/components/TopNav.tsx`
**What changed:**
- Button label: `أجر معانا` → `إضافة ليستنج`
- Icon: `Building2` → `Plus` (clearer call-to-action)
- Updated header comment

**Scope:** Only the nav button. All other places that say "أجر معانا" (welcome banners, dashboard labels, supplier branding) are untouched — your supplier branding stays consistent.

---

## 🔴 Findings I Did NOT Fix (Decisions Needed)

### A. WhatsApp admin alerts are silently failing
- **`agent_name = 'listing_draft_trigger'` and `'wa_review_notifier'`** — every send to `+201002229982` (you) is failing with Meta error `(#100) Invalid parameter`.
- **Root cause:** these are freeform messages going to you OUTSIDE the 24-hour WhatsApp service window. Meta only allows approved templates outside the window.
- **Why it slipped:** since you've started auto-approving everything, you don't actually need these alerts as much. But you DO want notifications when a draft arrives.
- **Fix options:**
  1. Convert these to a Meta-approved template message
  2. Stop sending these alerts to your WhatsApp; use push notifications + `/admin/listing-drafts` page instead
  3. Send yourself a daily digest at 8 AM via the template
- **My recommendation:** Option 2. The alerts are noise, and you already check `/admin/listing-drafts` (which now auto-refreshes every 30s).

### B. شيري's UX disaster (still in queue today, 12:50–13:11)
She wrote "هدخل للمرة الرابعة لاني زهقت" (entering for the 4th time, exhausted). The AI replied perfectly but the underlying duplicate-draft bug was the cause. The fixes above should prevent this for future users.
- **Action:** consider a quick follow-up WA message to her once the fixes are deployed: "اتصلحت المشكلة، جرّبي تاني وهيوصل لآخر خطوة كنتي واصلاها."

### C. RLS disabled on 4 tables (Supabase advisory)
- `supplier_post_shares`, `social_groups_catalog`, `social_pack_group_posts`, `social_packs`
- Anyone with the anon key can read/write these. Not urgent if those keys aren't public, but worth fixing in the next sprint.

---

## 🚀 Suggested Deploy Sequence (for now)

1. Copy the 3 files from `/mnt/user-data/outputs/madmona-changes-2026-05-12/` over your local copies in:
   - `C:\madmona-app\src\app\add-listing\AddListingClient.tsx`
   - `C:\madmona-app\src\app\api\listing-drafts\route.ts`
   - `C:\madmona-app\src\components\TopNav.tsx`
2. Run `deploy.bat`
3. After Vercel deploy completes, test:
   - Open `https://madmonacairo.com` in an incognito tab → check the new "إضافة ليستنج" button
   - Click it → fill step 1 → reload the page → confirm you continue the same draft (same step, same data)
   - Open `/admin/listing-drafts` → confirm the 16 drafts still visible with correct statuses
4. **Save a tag** (recommended after testing):
   ```bash
   git tag -a v2026.05.12-autoapprove -m "Auto-approve all registrations + dedup drafts + clean social packs"
   git push origin v2026.05.12-autoapprove
   ```

---

## 📊 Database State (Snapshot)

| Table | State | Count |
|---|---|---|
| marketplace_suppliers | approved | 19 |
| suppliers | approved | 3 |
| listings | published | 222 |
| listings | paused | 5 |
| listings | rejected | 1 |
| listing_drafts | claimed | 16 |
| content_calendar | placeholder | 0 (cleaned) |
| social_packs | active | 223 |

---

## 🎯 Outstanding Questions

1. **MUA campaign funnel** — does it land on `/mua.html` or `/add-listing?utm_source=fb&utm_campaign=mua`? Need to confirm the link in the active Meta ad matches.
2. **The "wrong photos" complaint** — is the root cause the Unsplash random-image flow (which is now fixed), or is there ANOTHER place where wrong images appear (Instagram posts already published, homepage hero, supplier dashboard)? If you have a specific listing URL or screenshot, I can dig deeper.
3. **"أجر معانا" branding** — should it stay in:
   - Dashboard cards ("أجر معانا (Suppliers)")
   - Welcome banner CTA
   - Booking page labels
   …or rename all of those to "موردين" / "أصحاب الإعلانات" / something else? My default was to leave them, since they're not user-facing entry points.
