// =====================================================================
// SNIPPET: Add Listing tab in your main navigation component
// =====================================================================
// Find your main navigation file (probably one of):
//   - app/components/Navbar.tsx
//   - app/components/Header.tsx
//   - components/layout/Header.tsx
//   - app/layout.tsx (if nav is inline)
//
// Add this Link to your nav items array:

import Link from 'next/link';

// Inside your <nav> element, alongside other Links:
<Link
  href="/add-listing"
  className="px-4 py-2 rounded-xl bg-[#B8860B] text-[#1F5F3F] font-semibold hover:bg-[#B8860B]/90 transition-all"
>
  أَجِّر معانا
</Link>

// =====================================================================
// OR — if you have a more structured nav config like this:
// =====================================================================

// Find something like this in your nav config and ADD the highlighted item:

const navItems = [
  { label: 'الرئيسية',     href: '/' },
  { label: 'استكشف',      href: '/explore' },
  // ▼ ADD THIS NEW ITEM ▼
  { label: 'أَجِّر معانا', href: '/add-listing', highlighted: true },
  // ▲ ADD THIS NEW ITEM ▲
  { label: 'تواصل معانا',  href: '/contact' },
];

// In the rendering loop, give the highlighted item the gold style:

{navItems.map((item) => (
  <Link
    key={item.href}
    href={item.href}
    className={
      item.highlighted
        ? 'px-4 py-2 rounded-xl bg-[#B8860B] text-[#1F5F3F] font-semibold'
        : 'px-3 py-2 text-[#FAF7F0] hover:text-[#B8860B]'
    }
  >
    {item.label}
  </Link>
))}

// =====================================================================
// MOBILE MENU
// =====================================================================
// If you have a mobile burger menu, add the same item there too.
// Make sure the gold "أَجِّر معانا" button is sticky/prominent on mobile —
// most users come from WhatsApp on phone.
