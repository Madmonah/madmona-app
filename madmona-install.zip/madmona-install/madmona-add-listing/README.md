# 🟢 مضمونة — Listing-First Signup Feature

## الفكرة
بدل ما نطلب من الناس يسجلوا حساب الأول (محبط)، احنا بنخليهم يضيفوا الليستنج
الأول، ولما يخلصوا نقولهم "كمل تسجيلك في دقيقة عشان تتحكم في إعلانك".
بالطريقة دي بناخد أهم بيانات (الليستنج) قبل ما العميل يقرر يسيب الموقع.

---

## ✅ اللي اتعمل في Supabase (تلقائيًا)
- ✅ جدول `listing_drafts` (مع RLS للأنونيموس)
- ✅ Function `claim_listing_draft(token, profile_id)` — تحول الـ draft لـ listing + supplier
- ✅ Function `get_listing_draft(token)`
- ✅ View `v_listing_drafts_funnel` (للداشبورد)
- ✅ Storage bucket `listing-drafts` (للصور)

**مفيش حاجة محتاج تعملها يدوي في Supabase. كله جاهز.**

---

## 📁 الملفات اللي محتاج تنسخها للـ repo

```
madmona-app/
├── app/
│   ├── add-listing/
│   │   ├── page.tsx                      ← الصفحة الرئيسية للنموذج
│   │   └── success/
│   │       └── page.tsx                  ← شاشة "تم!" + CTA لإنشاء الحساب
│   │
│   └── api/
│       └── listing-drafts/
│           ├── route.ts                  ← POST/PATCH/GET drafts
│           ├── upload/
│           │   └── route.ts              ← رفع صور لـ Supabase Storage
│           └── claim/
│               └── route.ts              ← تحويل draft → listing بعد التسجيل
```

---

## 🚀 خطوات النشر

### 1. انسخ الملفات للريبو
```cmd
cd C:\madmona-app
xcopy /E /I [path-to-this-folder]\app .\app
```

أو يدوي: انسخ كل ملف للمكان المظبوط حسب الشكل اللي فوق.

### 2. تأكد من الـ environment variables
في `.env.local` لازم يكون عندك:
```
NEXT_PUBLIC_SUPABASE_URL=https://mjhflxpxunwycbiquoig.supabase.co
SUPABASE_SERVICE_ROLE_KEY=<your-service-role-key>
```

### 3. ضيف الـ "أجر معانا" tab في الـ Navigation
شوف ملف `NAVIGATION_SNIPPET.tsx` للسناب. أضف Link لـ `/add-listing` في
الـ Navbar الرئيسي بـ styling مميز (الذهبي #B8860B).

### 4. اربط الـ signup page بالـ claim
في صفحة التسجيل بعد ما اليوزر يخلص signup:

```typescript
// بعد ما الـ profile يتعمل بنجاح
const params = new URLSearchParams(window.location.search);
const draftToken = params.get('token');

if (draftToken) {
  await fetch('/api/listing-drafts/claim', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      token: draftToken,
      profile_id: newProfile.id,
    }),
  });
  router.push('/dashboard?welcome=1');
}
```

### 5. Deploy
```cmd
deploy.bat
```

---

## 🧪 اختبر بنفسك
بعد النشر، روح على:
```
https://madmonacairo.com/add-listing?phone=01XXXXXXXXX&utm_source=whatsapp
```

ولو عايز تختبر من رقم معين:
```
https://madmonacairo.com/add-listing?phone=01070597118&utm_source=whatsapp&utm_campaign=manual_test
```

---

## 🔁 الـ flow الكامل

```
عميل في الواتس اب
   ↓
يضغط لينك madmonacairo.com/add-listing?phone=...
   ↓
[الصفحة بتعرف رقمه من URL، مفيش حاجة يكتبها]
   ↓
خطوة 1: نوع المنتج (شقة، عربية، إلخ)
خطوة 2: العنوان والمكان
خطوة 3: السعر
خطوة 4: الصور (اختياري)
خطوة 5: اسمه + رقمه + فرد/شركة
   ↓
[ينضغط "ابعت الليستنج 🚀"]
   ↓
- Draft بيتحفظ في DB بـ status='submitted'
- بيتبعت رسالة واتس اب تأكيد للعميل تلقائيًا
- بيتحول لصفحة /add-listing/success
   ↓
"تم! اعمل حسابك في دقيقة عشان تتحكم في إعلانك"
   ↓
[يضغط "أنشئ حسابي دلوقتي"]
   ↓
صفحة /signup?token=...&phone=...
[يعمل OTP عبر الواتس اب]
   ↓
بعد ما الحساب يتعمل، الـ /api/listing-drafts/claim بتاخد الـ token
   ↓
- بتعمل marketplace_supplier (لو مفيش)
- بتعمل listing بـ status='pending_review'
- بتعمل pricing_rule
- بتنقل الصور لـ listing_photos
- بتعلم الـ draft بـ status='claimed'
   ↓
العميل بيدخل /dashboard ويلاقي إعلانه + يقدر يدير حسابه
```

---

## 📊 المتابعة (Admin)
كل draft هيتسجل في `public.listing_drafts`. لمتابعة الـ funnel:

```sql
-- View جاهز
SELECT * FROM v_listing_drafts_funnel ORDER BY day DESC;

-- Drafts اللي مكملوش
SELECT * FROM listing_drafts
WHERE status = 'draft'
  AND created_at > now() - interval '7 days'
ORDER BY created_at DESC;

-- Drafts اتسلمت ومحدش حول لـ account
SELECT * FROM listing_drafts
WHERE status = 'submitted'
  AND created_at < now() - interval '24 hours'
  AND claimed_at IS NULL;
```

---

## 🎯 الإحصائيات المتوقعة
- **النسبة المتوقعة لإكمال الـ form**: 35-50% (مقابل 9% الحالية للتسجيل التقليدي)
- **النسبة المتوقعة لتحويل draft → claimed account**: 60-70%
- **التحسن الإجمالي للـ funnel**: ~3x

---

## ⚠️ ملاحظات مهمة

### الأمان
- الـ `SUPABASE_SERVICE_ROLE_KEY` لازم يكون **server-side فقط**، مش في الكلاينت
- الـ rate limiting على الـ POST handler ممكن تضيفه لاحقًا (Upstash Redis)
- الـ photo upload محدود بـ 8MB لكل صورة، 8 صور كحد أقصى

### الـ UX
- الـ form يحفظ progress تلقائيًا بعد كل خطوة (لو العميل قفل المتصفح بيرجع من نفس النقطة لو فتح اللينك تاني بنفس الـ token)
- مفيش OTP في الـ form نفسه — العميل بياخد رسالة واتس اب تأكيد بعد الإرسال

### للمستقبل (لو عايز تطور)
- ضيف pre-fill من Google Maps للعنوان والـ coordinates
- ضيف AI لاقتراح العنوان والوصف من الصور
- ضيف "أكمل الإعلان لاحقًا" بدل ما العميل يخلص كل خطوة

---

## 🆘 Troubleshooting

**المشكلة: الصور مش بتترفع**
- تأكد إن الـ bucket `listing-drafts` موجود (شيك في Supabase Dashboard → Storage)
- تأكد إن الـ SUPABASE_SERVICE_ROLE_KEY موجود في .env

**المشكلة: الفورم بيقولي "حصل خطأ"**
- شوف الـ console logs (Vercel Functions logs)
- تأكد إن جدول `listing_drafts` موجود (شيك في Supabase Dashboard → Table Editor)

**المشكلة: الـ claim مش شغال بعد التسجيل**
- شيك في الـ logs لو الـ function `claim_listing_draft` رمت error
- تأكد إن الـ profile_id بتاع المستخدم الجديد بيتبعت بشكل صح

---

## 📞 خلصت
أي سؤال أو مشكلة، الكود كله واضح ومعلق. ابدأ بنشر الفايلز ولو فيه مشكلة كلمني.
