// components/MadmonaListingClaimer.tsx
// =====================================================================
// Auto-claims a listing draft when a logged-in user visits any URL
// containing ?token=<...>. Drop this once in the root layout —
// no need to edit the signup page manually.
// =====================================================================

'use client';

import { useEffect } from 'react';
import { usePathname, useSearchParams } from 'next/navigation';
import { createBrowserClient } from '@supabase/ssr';

const CLAIMED_KEY = 'madmona_claimed_tokens';

export default function MadmonaListingClaimer() {
  const params = useSearchParams();
  const pathname = usePathname();

  useEffect(() => {
    const token = params.get('token');
    if (!token) return;

    // Skip claim if we're inside the /add-listing wizard itself —
    // the token there means "edit draft", not "claim it"
    if (pathname?.startsWith('/add-listing')) return;

    // Dedupe: don't claim the same token twice in one browser
    try {
      const claimed: string[] = JSON.parse(localStorage.getItem(CLAIMED_KEY) || '[]');
      if (claimed.includes(token)) return;
    } catch {}

    (async () => {
      try {
        // Get current user
        const supabase = createBrowserClient(
          process.env.NEXT_PUBLIC_SUPABASE_URL!,
          process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
        );
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return; // wait until they sign up

        const res = await fetch('/api/listing-drafts/claim', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ token, profile_id: user.id }),
        });
        const json = await res.json();
        if (json?.success) {
          // Remember we claimed this one
          try {
            const claimed: string[] = JSON.parse(localStorage.getItem(CLAIMED_KEY) || '[]');
            claimed.push(token);
            localStorage.setItem(CLAIMED_KEY, JSON.stringify(claimed));
          } catch {}

          // Toast / nudge
          if (typeof window !== 'undefined') {
            const banner = document.createElement('div');
            banner.style.cssText = `
              position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%);
              background: #1F5F3F; color: #FAF7F0; padding: 16px 24px;
              border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.3);
              z-index: 9999; font-family: system-ui; font-size: 14px;
              direction: rtl; text-align: center; max-width: 90vw;
              border: 1px solid rgba(184,134,11,0.4);
            `;
            banner.innerHTML =
              '🎉 <strong>تم ربط إعلانك بحسابك!</strong><br>' +
              '<span style="opacity:0.8; font-size:12px;">إعلانك دلوقتي في انتظار المراجعة في لوحة التحكم</span>';
            document.body.appendChild(banner);
            setTimeout(() => banner.remove(), 6000);
          }
        }
      } catch (e) {
        console.warn('Listing claim failed:', e);
      }
    })();
  }, [params, pathname]);

  return null;
}
