-- Run this once in Supabase SQL editor (or auto-run as migration)
-- Creates a public bucket for the anonymous listing draft photos

-- 1. Create bucket if it doesn't exist
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'listing-drafts',
  'listing-drafts',
  true,                              -- public read so the page can show thumbnails
  8388608,                           -- 8 MB
  ARRAY['image/jpeg','image/png','image/webp','image/heic']
)
ON CONFLICT (id) DO UPDATE
  SET public = true,
      file_size_limit = 8388608,
      allowed_mime_types = ARRAY['image/jpeg','image/png','image/webp','image/heic'];

-- 2. RLS for bucket
DROP POLICY IF EXISTS "anon_can_upload_listing_drafts" ON storage.objects;
CREATE POLICY "anon_can_upload_listing_drafts"
  ON storage.objects FOR INSERT
  TO anon, authenticated
  WITH CHECK (bucket_id = 'listing-drafts');

DROP POLICY IF EXISTS "public_read_listing_drafts" ON storage.objects;
CREATE POLICY "public_read_listing_drafts"
  ON storage.objects FOR SELECT
  TO anon, authenticated
  USING (bucket_id = 'listing-drafts');
